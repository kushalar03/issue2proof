def total(subtotal, discount):
    return subtotal - discount
