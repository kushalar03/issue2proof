from pricing import total

def test_boundaries():
    for subtotal, discount, expected in [(0, 0, 0), (50, 50, 0), (75, 0, 75), (10, 11, 0)]:
        assert total(subtotal, discount) == expected
