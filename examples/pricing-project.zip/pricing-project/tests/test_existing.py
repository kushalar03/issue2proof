from pricing import total

def test_normal_discount():
    assert total(100, 20) == 80
